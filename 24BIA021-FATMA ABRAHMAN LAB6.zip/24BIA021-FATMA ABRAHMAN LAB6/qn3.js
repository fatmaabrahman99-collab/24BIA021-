

function Circle(radius) {
    this.radius = radius;

    this.getArea = function() {
        return Math.PI * this.radius * this.radius;
    };

    this.getPerimeter = function() {
        return 2 * Math.PI * this.radius;
    };
}

let circy1 = new Circle(11);
console.log(circy1.getArea());

let circy2 = new Circle(4.44);
console.log(circy2.getPerimeter());

