

// Function Declaration
function percentageOfWorld1(population) {
    return (population / 7900) * 100;
}

let China1= percentageOfWorld1(1441);
let kenya1 = percentageOfWorld1(200);
let Uganda1= percentageOfWorld1(150);

console.log(" China1 " + China1);
console.log(" kenya1 " + kenya1);
console.log(" Uganda1 " + Uganda1);


// Function Expression
const percentageOfWorld2 = function(population) {
    return (population / 7900) * 100;
};

let China2= percentageOfWorld2(1441);
let kenya2 = percentageOfWorld2(200);
let Uganda2= percentageOfWorld2(150);

console.log(" China2 " + China2);
console.log(" kenya2 " + kenya2);
console.log(" Uganda2 " + Uganda2);

// Arrow Function
const percentageOfWorld3 = function(population) {
    return (population / 7900) * 100;
};

let China3= percentageOfWorld3(1441);
let kenya3 = percentageOfWorld3(200);
let Uganda3= percentageOfWorld3(150);

console.log(" China3 " + China3);
console.log(" kenya3 " + kenya3);
console.log(" Uganda3 " + Uganda3);
