


let myCountry = {
    country: "Tanzania",
    capital: "Dodoma",
    language: "Swahili",
    population: 70,
    neighbours: ["Kenya", "Uganda", "Rwanda", "Burundi"],

    describe: function() {
        console.log(
            this.country + " has " +
            this.population + " million " +
            this.language + "-speaking people, " +
            this.neighbours.length +
            " neighbouring countries and a capital called " +
            this.capital + "."
        );
    },

    checkIsland: function() {
        this.isIsland =
            this.neighbours.length === 0 ? true : false;
    }
};


console.log(
    myCountry.country + " has " +
    myCountry.population + " million " +
    myCountry.language + "-speaking people, " +
    myCountry.neighbours.length +
    " neighbouring countries and a capital called " +
    myCountry.capital + "."
);

myCountry.population += 2;


myCountry["population"] -= 2;



myCountry.describe();

myCountry.checkIsland();

console.log(myCountry.isIsland);



